import React, { useState,useContext } from 'react';
import { Link } from 'react-router-dom';
import Nav from 'react-bootstrap/Nav';
import NavDropdown from 'react-bootstrap/NavDropdown';
import {BookContext} from './createContext';
import "./App.css"



function BookStoreApp() {
  
  const [carts,setCarts] = useContext(BookContext);

  const ImgContainerStyle = {
    height: '200px',
    width: '300px',
    backgroundColor: 'red',
  };

  const bookListData = [
    {
      "author": "Chinua Achebe",
      "country": "Nigeria",
      "imageLink": "images/things-fall-apart.jpg",
      "language": "English",
      "link": "https://upload.wikimedia.org/wikipedia/en/6/65/ThingsFallApart.jpg",
      "pages": 209,
      "title": "Things Fall Apart",
      "year": 1958
    },
    {
      "author": "Hans Christian Andersen",
      "country": "Denmark",
      "imageLink": "images/fairy-tales.jpg",
      "language": "Danish",
      "link": "https://upload.wikimedia.org/wikipedia/commons/5/5b/Hans_Christian_Andersen_%281834_painting%29.jpg",
      "pages": 784,
      "title": "Fairy tales",
      "year": 1836
    },
    {
      "author": "Dante Alighieri",
      "country": "Italy",
      "imageLink": "images/the-divine-comedy.jpg",
      "language": "Italian",
      "link": "https://upload.wikimedia.org/wikipedia/commons/7/7b/Dante_Domenico_di_Michelino.jpg",
      "pages": 928,
      "title": "The Divine Comedy",
      "year": 1315
    },
    {
      "author": "Unknown",
      "country": "Sumer and Akkadian Empire",
      "imageLink": "images/the-epic-of-gilgamesh.jpg",
      "language": "Akkadian",
      "link": "https://upload.wikimedia.org/wikipedia/commons/7/7a/British_Museum_Flood_Tablet.jpg",
      "pages": 160,
      "title": "The Epic Of Gilgamesh",
      "year": -1700
    },
    {
      "author": "Unknown",
      "country": "Achaemenid Empire",
      "imageLink": "images/the-book-of-job.jpg",
      "language": "Hebrew",
      "link": "https://upload.wikimedia.org/wikipedia/commons/7/75/Aleppo_Codex_Joshua_1_1.jpg",
      "pages": 176,
      "title": "The Book Of Job",
      "year": -600
    },
    {
      "author": "Unknown",
      "country": "India/Iran/Iraq/Egypt/Tajikistan",
      "imageLink": "images/one-thousand-and-one-nights.jpg",
      "language": "Arabic",
      "link": "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/Cassim.jpg/440px-Cassim.jpg",
      "pages": 288,
      "title": "One Thousand and One Nights",
      "year": 1200
    }]
    
    const [cart, setCart] = useState([]);
    const [cartLength, setCartLength] = useState(0);

    // const handleButtonClick = (book) => {
    //   window.location.href = book.link;
    // };

    const handleButtonClick = (book) => {
      window.open(book.link, '_blank');
    };

    const addBook = (book) => {
      setCart([...cart, book]);
      setCarts(cart)
      setCartLength(cart.length+1);
    };

    const removeBook = (index) => {
      const updatedCart = [...cart];
      updatedCart.splice(index, 1);
      setCart(updatedCart);
      setCartLength(updatedCart.length);
      setCarts(updatedCart)

    };
    

    const renderCartItems = () => {


      return (
        <ul>
          {cart.map((book, index) => (
            <div style={{marginTop:'6%'}} key={index}>
              <img style={{height:'5%',width:'5%',marginBottom:'-3%'}} src={book.link} alt={book.title} />
              <h5 style={{marginTop:'4%'}}>{book.title}</h5>
              <p>Language: <p>{book.language}</p></p>
              <p>Author: <p>{book.author}</p></p>
              <button onClick={() => removeBook(index)}>Remove</button>
            </div>
          ))}
        </ul>
      );
    };
    
    
    const [isCartVisible, setIsCartVisible] = useState(false);
    
    const toggleCartVisibility = () => {
      setIsCartVisible(!isCartVisible);
    };
    
    const handleSelect = (eventKey) => alert(`All your select items in the cart will be lost`);
        
    
      // const [bookList, setBookList] = useState(bookListData); // Use `bookListData` instead of `bookList`
    
      return (
        <div style={{marginTop:'2%',marginLeft:'2%'}}>
        
      <Nav variant="pills" activeKey="1" onSelect={handleSelect}>
      <Nav.Item>
        <Nav.Link eventKey="1" href={window.location.href}>
         Refresh Cart
        </Nav.Link>
      </Nav.Item>
      <Nav.Item>
        <Nav.Link eventKey="2" title="Item">
          Filter By Price Lowest To Highest
        </Nav.Link>
      </Nav.Item>
      <Nav.Item>
        <Nav.Link eventKey="3" enabled>
        Filter By Price Highest To Lowest
        </Nav.Link>
      </Nav.Item>
      <NavDropdown title="Filter By Genre" id="nav-dropdown">
        <NavDropdown.Item >Action</NavDropdown.Item>
        <NavDropdown.Item >Adventure</NavDropdown.Item>
        <NavDropdown.Item >Love</NavDropdown.Item>
        <NavDropdown.Divider />
        <NavDropdown.Item>Unique</NavDropdown.Item>
      </NavDropdown>
      </Nav>
  
          <h1 style={{ textAlign: 'center',marginTop:'2%' }}>Welcome To Book Store App</h1>
          <p style={{ color:'orange', textAlign: 'center',marginTop:'2%' }}>Please scroll left & right to view your books</p>
           <div className="container">
         
          
            {bookListData.map((book, index) => (
              <div key={index}>
               
                <img style={ImgContainerStyle} src={book.link} alt={book.title} />
              <div style={{ marginTop:'5%' }}>
                  <h4>{book.title}</h4>
                 <h5>Language: <p style={{ color: 'red' }}>{book.language}</p></h5> 
                 <h5>Author: <p style={{ color: 'green' }}>{book.author}</p></h5> 
                 <h5>Year: <p style={{ color: 'orange' }}>{book.year}</p></h5> 
                  <button  onClick={() => addBook(book)}>Add Book</button>
                  <br></br>
                  <br></br>
                  <button onClick={handleButtonClick.bind(null, book)}>More Details</button>
                <div>
             
              </div>
              
                </div>
                
              </div>
              
            ))}
          </div>
        
        <div>
        <h1 style={{ textAlign: 'center',marginTop:'2%' }}>Click On Your Cart Below To Edit Your Items</h1>
        {isCartVisible && renderCartItems()} {/* Conditional rendering of cart items */}
        <h4 className="cart-emoji">Total <span style={{color:'red',marginLeft:'2%',marginRight:'2%'}}> {cartLength} </span> items in your cart</h4>
        <button className="cart-button" onClick={toggleCartVisibility}>
          {isCartVisible ? "Hide Cart" : "Show Cart "}
        </button>
        <img className="cart-emoji" style={{height:'5%',width:'5%'}}src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHM77I1vm6e38Y0SXDuPFvMMrAdNeMXzIwiGggM5Q&s" alt="here" onClick={toggleCartVisibility} />
        </div>
          
          <Link to="/check_out" className="checkout-button">Click Here To Check Out</Link>
          
        </div>
      );
    }

    

    export default BookStoreApp;